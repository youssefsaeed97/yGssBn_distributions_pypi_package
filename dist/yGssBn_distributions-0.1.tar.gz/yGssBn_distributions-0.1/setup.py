from setuptools import setup

setup(name='yGssBn_distributions',
      version='0.1',
      description='Gaussian & Binomial distributions',
      packages=['yGssBn_distributions'],
      author = 'Youssef Saeed',
      author_email = 'y0uss3f071997@gmail.com',
      zip_safe=False)
